package nl.tudelft.semmaps.v1;

public interface RouteSegment {
    Coordinates from();
    Coordinates to();
    long getDuration();
    long getDistance();
}
