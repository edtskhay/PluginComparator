package nl.tudelft.semmaps.v1;

import java.util.List;

public class Main {
    // Dependency injection (CSEP)
    public static Router router;
    public static AddressDatabase addressDatabase;
    public static LocationService locationService;

    public static List<Route> navigateTo(Address address) {
        return navigate(locationService.currentLocation(), address.getCoordinates());
    }

    public static List<Route> navigate(Coordinates from, Coordinates to) {
        return router.calculateRoutes(from, to);
    }
}