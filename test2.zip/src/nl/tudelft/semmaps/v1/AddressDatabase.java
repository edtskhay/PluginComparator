package nl.tudelft.semmaps.v1;

import java.util.List;

public class AddressDatabase {
    public List<Address> search(String input) {}
}
