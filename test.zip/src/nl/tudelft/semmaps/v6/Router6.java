package nl.tudelft.semmaps.v6;

import nl.tudelft.semmaps.v1.Coordinates;
import nl.tudelft.semmaps.v1.Route;

import java.sql.Time;
import java.util.List;

public class Router6 {
    public List<Route> calculateRoutes(RouteStrategy strategy, Time start, Coordinates from, Coordinates to) {
        return List.of(
            strategy.fastestRoute(start, from, to),
            strategy.bestRoute(start, from, to)
        );
    }
}
