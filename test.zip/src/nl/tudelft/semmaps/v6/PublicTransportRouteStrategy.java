package nl.tudelft.semmaps.v6;

import nl.tudelft.semmaps.v1.Coordinates;
import nl.tudelft.semmaps.v1.Route;
import nl.tudelft.semmaps.v4.TimedGraph;

import java.sql.Time;

// Public transport is complicated because time is a factor, and because we also may need to
// travel a significant distance from the public transport start and end locations
public class PublicTransportRouteStrategy implements RouteStrategy {
    private final RouteStrategy strategyToStartPoint;
    private final RouteStrategy strategyToEndPoint;
    private TimedGraph graph;

    public PublicTransportRouteStrategy(RouteStrategy startPoint, RouteStrategy endPoint) {
        strategyToStartPoint = startPoint;
        strategyToEndPoint = endPoint;
    }

    @Override
    public Route fastestRoute(Time start, Coordinates from, Coordinates to) {
        Coordinates ptStart = graph.findClosestNode(from).toCoordinates();
        Coordinates ptEnd = graph.findClosestNode(to).toCoordinates();

        // Route to start point of public transport
        strategyToStartPoint.fastestRoute(start, from, ptStart);

        // Navigate with public transport
        graph.findShortestDurationPaths(ptStart, ptEnd);

        // Navigate to destination
        strategyToEndPoint.fastestRoute(start, ptEnd, to);
    }
}
