package nl.tudelft.semmaps.v6;

public class BikeRouteStrategy implements RouteStrategy {
    // logic for bike routing
}
