package nl.tudelft.semmaps.v6;

public class CarRouteStrategy implements RouteStrategy {
    // logic for car routing
}
