package nl.tudelft.semmaps.v6;

import nl.tudelft.semmaps.v1.Coordinates;
import nl.tudelft.semmaps.v1.Route;

import java.sql.Time;

public interface RouteStrategy {
    Route fastestRoute(Time start, Coordinates from, Coordinates to);
    Route bestRoute(Time start, Coordinates from, Coordinates to);
}
