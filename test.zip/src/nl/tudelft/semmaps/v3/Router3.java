package nl.tudelft.semmaps.v3;

import nl.tudelft.semmaps.v1.Coordinates;
import nl.tudelft.semmaps.v1.Graph;
import nl.tudelft.semmaps.v1.Route;

import java.util.List;

public class Router3 {
    private Graph carGraph;
    private Graph walkGraph;
    private Graph bikeGraph;

    public List<Route> calculateCarRoutes(Coordinates from, Coordinates to) {
        return calculateRoutes(carGraph, from, to);
    }

    public List<Route> calculateWalkRoutes(Coordinates from, Coordinates to) {
        return calculateRoutes(walkGraph, from, to);
    }

    public List<Route> calculateBikeRoutes(Coordinates from, Coordinates to) {
        return calculateRoutes(bikeGraph, from, to);
    }

    private List<Route> calculateRoutes(Graph graph, Coordinates from, Coordinates to) {
        return List.of(
                fastestPath(graph, from, to),
                shortestPath(graph, from, to)
        );
    }

    private Route shortestPath(Graph graph, Coordinates from, Coordinates to) { }
    private Route fastestPath(Graph graph, Coordinates from, Coordinates to) { }
}