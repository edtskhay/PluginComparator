package nl.tudelft.semmaps.v4;

import nl.tudelft.semmaps.v1.Graph;

public interface TimedGraph extends Graph {
    // ...
}
