package nl.tudelft.semmaps.v1;

public interface Address {
    String getStreet();
    int getNumber();
    String getZipCode();
    String getCity();
    String getCountry();
    Coordinates getCoordinates();
}
