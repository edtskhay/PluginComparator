package nl.tudelft.semmaps.v1;

public class LocationService {
    public Coordinates currentLocation() {
        // Get current location from device
    }
}
