package nl.tudelft.semmaps.v1;

import java.util.List;

public class Router {
    private Graph roadGraph;

    public List<Route> calculateRoutes(Coordinates from, Coordinates to) {
        return List.of(
            fastestPath(from, to),
            shortestPath(from, to)
        );
    }

    private Route shortestPath(Coordinates from, Coordinates to) { }
    private Route fastestPath(Coordinates from, Coordinates to) { }
}
