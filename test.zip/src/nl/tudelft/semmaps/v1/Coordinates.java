package nl.tudelft.semmaps.v1;

public interface Coordinates {
    long getLatitude();
    long getLongitude();
}
