package nl.tudelft.semmaps.v1;

import java.util.List;

public interface Route {
    List<RouteSegment> getRouteSegments();
    long getDuration(); //seconds
    long getDistance(); //meters
}
