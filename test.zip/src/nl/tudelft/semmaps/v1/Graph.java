package nl.tudelft.semmaps.v1;

import java.util.List;

/**
 * Represents a graph which models a road network.
 */
public interface Graph {
    interface Node {
        Coordinates toCoordinates();
    }

    interface Edge {
        Node start();
        Node end();
        long length();
        long duration();
        RouteSegment toRouteSegment();
    }

    // To start navigation, we need to find the starting spot in our graph
    Node findClosestNode(Coordinates point);
    List<Node> findCloseNodes(Coordinates point);

    // Finds several sensible paths from start to end
    List<List<Edge>> findShortestLengthPaths(Coordinates start, Coordinates end);

    // Finds several sensible paths from start to end
    List<List<Edge>> findShortestDurationPaths(Coordinates start, Coordinates end);
}


