package nl.tudelft.semmaps.v2;

public enum NavigationMethod {
    CAR,
    BIKE,
    WALK
}
