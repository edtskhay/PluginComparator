package nl.tudelft.semmaps.v2;

import nl.tudelft.semmaps.v1.*;

import java.util.List;

public class Main2 {
    // Dependency injection (CSEP)
    public static Router2 router;
    public static AddressDatabase addressDatabase;
    public static LocationService locationService;

    public static List<Route> navigateTo(NavigationMethod method, Address address) {
        return navigate(method, locationService.currentLocation(), address.getCoordinates());
    }

    public static List<Route> navigate(NavigationMethod method, Coordinates from, Coordinates to) {
        if (method == NavigationMethod.CAR) {
            return router.calculateCarRoutes(from, to);
        } else if (method == NavigationMethod.BIKE) {
            return router.calculateBikeRoutes(from, to);
        } else if (method == NavigationMethod.WALK) {
            return router.calculateWalkRoutes(from, to);
        }
    }
}

