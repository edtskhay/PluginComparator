package nl.tudelft.semmaps.v2;

import nl.tudelft.semmaps.v1.Coordinates;
import nl.tudelft.semmaps.v1.Graph;
import nl.tudelft.semmaps.v1.Route;

import java.util.List;

public class Router2 {
    private Graph carGraph;
    private Graph walkGraph;
    private Graph bikeGraph;

    public List<Route> calculateCarRoutes(Coordinates from, Coordinates to) {
        return List.of(
            fastestPath(carGraph, from, to),
            shortestPath(carGraph, from, to)
        );
    }

    public List<Route> calculateWalkRoutes(Coordinates from, Coordinates to) {
        return List.of(
                fastestPath(walkGraph, from, to),
                shortestPath(walkGraph, from, to)
        );
    }

    public List<Route> calculateBikeRoutes(Coordinates from, Coordinates to) {
        return List.of(
                fastestPath(bikeGraph, from, to),
                shortestPath(bikeGraph, from, to)
        );
    }

    private Route shortestPath(Graph graph, Coordinates from, Coordinates to) { }
    private Route fastestPath(Graph graph, Coordinates from, Coordinates to) { }
}