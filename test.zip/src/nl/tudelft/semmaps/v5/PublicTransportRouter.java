package nl.tudelft.semmaps.v5;

import nl.tudelft.semmaps.v1.Coordinates;
import nl.tudelft.semmaps.v1.Route;
import nl.tudelft.semmaps.v4.TimedGraph;

import java.sql.Time;
import java.util.List;

public class PublicTransportRouter {
    private TimedGraph graph;

    private Route fastest(Time start, Coordinates from, Coordinates to) {
        // pretty complicated method
    }
    private Route moreTransferTime(Time start, Coordinates from, Coordinates to) {
        // pretty complicated method
    }
    private Route fewestTransfers(Time start, Coordinates from, Coordinates to) {
        // pretty complicated method
    }
    private Route preferNonBus(Time start, Coordinates from, Coordinates to) {
        // pretty complicated method
    }

    public List<Route> calculatePublicTransportRoutes(Time start, Coordinates from, Coordinates to) {
        return List.of(
                fastest(start, from, to),
                moreTransferTime(start, from, to),
                fewestTransfers(start, from, to),
                preferNonBus(start, from, to)
        );
    }
}
