# helloworld
When you need a really simple Java application for testing.
```
# run with
java -jar helloworld.jar
```
```
# prints
Hello world from HelloWorld.jar!
```
